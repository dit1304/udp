
### INSTALL SCRIPT 
```
apt install -y && apt update -y && apt upgrade -y && wget -q https://raw.githubusercontent.com/YINNSTORE/VVIP/main/main.sh && chmod +x main.sh && ./main.sh
```

## UPDATE SCRIPT
```
WGET LU TAII
```

### UDP
```
wget https://raw.githubusercontent.com/Azigaming404/Autoscript-by-azi/main/udp/udp-custom.sh && chmod +x udp-custom.sh && ./udp-custom.sh
```

### WORK DI OS
- UBUNTU 20.04.05
- DEBIAN 10 ( Disarankan )

### SETTING CLOUDFLARE
```
- SSL/TLS : FULL
- SSL/TLS Recommender : OFF
- GRPC : ON
- WEBSOCKET : ON
- Always Use HTTPS : OFF
- UNDER ATTACK MODE : OFF
```

### `WARNING !`
```
Jika Mendapatkan Status Service Off
Silahkan Restart Service.
Jika Statsus Service Masih Off
Silahkan Reboot vps kalian
```
